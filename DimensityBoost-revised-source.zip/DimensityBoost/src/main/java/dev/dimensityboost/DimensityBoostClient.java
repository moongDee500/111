package dev.dimensityboost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class DimensityBoostClient implements ClientModInitializer {
    private static final Path CONFIG = Path.of("config", "dimensityboost.properties");
    private static final long[] LOOP_TIMES = new long[100];
    private static int loopIndex;
    private static long lastLoopNs = System.nanoTime();
    private static long lastAutoAdjustMs;
    private static KeyBinding cycleModeKey;
    private static KeyBinding toggleHudKey;
    private static Mode mode = Mode.BALANCED;
    private static boolean hudEnabled = true;

    private enum Mode {
        PERFORMANCE("性能优先", 8),
        BALANCED("均衡", 12),
        COOL("低发热", 7),
        AUTO("自动调节", 12);

        final String label;
        final int maxDistance;
        Mode(String label, int maxDistance) {
            this.label = label;
            this.maxDistance = maxDistance;
        }
    }

    @Override
    public void onInitializeClient() {
        loadConfig();
        cycleModeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dimensityboost.cycle_mode", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_O, KeyBinding.Category.MISC));
        toggleHudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dimensityboost.toggle_hud", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_I, KeyBinding.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            long now = System.nanoTime();
            LOOP_TIMES[loopIndex++ % LOOP_TIMES.length] = now - lastLoopNs;
            lastLoopNs = now;

            while (cycleModeKey.wasPressed()) {
                mode = Mode.values()[(mode.ordinal() + 1) % Mode.values().length];
                if (mode != Mode.AUTO) applyPreset(client);
                saveConfig();
                if (client.player != null) client.player.sendMessage(
                        Text.literal("DimensityBoost：已切换到 " + mode.label).formatted(Formatting.AQUA), true);
            }
            while (toggleHudKey.wasPressed()) {
                hudEnabled = !hudEnabled;
                saveConfig();
                if (client.player != null) client.player.sendMessage(
                        Text.literal("DimensityBoost：性能 HUD " + (hudEnabled ? "已开启" : "已关闭"))
                                .formatted(Formatting.AQUA), true);
            }

            if (client.player != null && client.world != null) {
                if (mode == Mode.AUTO) autoAdjust(client);
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            if (!hudEnabled) return;
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.world == null) return;
            Runtime rt = Runtime.getRuntime();
            long usedMb = (rt.totalMemory() - rt.freeMemory()) / (1024L * 1024L);
            long maxMb = rt.maxMemory() / (1024L * 1024L);
            int fps = client.getCurrentFps();
            double loopMs = averageLoopMs();
            int x = 8, y = 8;
            drawContext.drawTextWithShadow(client.textRenderer,
                    Text.literal("DimensityBoost | " + mode.label).formatted(Formatting.AQUA), x, y, 0xFFFFFF);
            drawContext.drawTextWithShadow(client.textRenderer,
                    Text.literal("FPS: " + fps + "   客户端循环: " + String.format("%.1f", loopMs) + " ms")
                            .formatted(fps >= 55 ? Formatting.GREEN : fps >= 30 ? Formatting.YELLOW : Formatting.RED),
                    x, y + 11, 0xFFFFFF);
            drawContext.drawTextWithShadow(client.textRenderer,
                    Text.literal("内存: " + usedMb + "/" + maxMb + " MB   渲染距离: " +
                            client.options.getViewDistance().getValue()), x, y + 22, 0xFFFFFF);
            drawContext.drawTextWithShadow(client.textRenderer,
                    Text.literal("O：切换模式   I：开关 HUD").formatted(Formatting.GRAY), x, y + 33, 0xFFFFFF);
        });
    }

    private static void applyPreset(MinecraftClient client) {
        if (client.options == null || mode == Mode.AUTO) return;
        int distance = mode.maxDistance;
        if (client.options.getViewDistance().getValue() != distance) {
            client.options.getViewDistance().setValue(distance);
        }
    }

    private static void autoAdjust(MinecraftClient client) {
        long now = System.currentTimeMillis();
        if (now - lastAutoAdjustMs < 5000L) return;
        lastAutoAdjustMs = now;
        int current = client.options.getViewDistance().getValue();
        int fps = client.getCurrentFps();
        int target = current;
        // AUTO 模式将视距限制在 5–12，避免自动模式无限降低或升高。
        if (fps > 0 && fps < 28 && current > 5) target = current - 1;
        else if (fps >= 58 && current < 12) target = current + 1;
        if (target != current) client.options.getViewDistance().setValue(target);
    }

    private static double averageLoopMs() {
        double sum = 0;
        int count = 0;
        for (long n : LOOP_TIMES) if (n > 0) { sum += n / 1_000_000.0; count++; }
        return count == 0 ? 0 : sum / count;
    }

    private static void loadConfig() {
        try {
            Files.createDirectories(CONFIG.getParent());
            if (!Files.exists(CONFIG)) return;
            Properties p = new Properties();
            try (var in = Files.newInputStream(CONFIG)) { p.load(in); }
            try { mode = Mode.valueOf(p.getProperty("mode", "BALANCED")); }
            catch (IllegalArgumentException ignored) { mode = Mode.BALANCED; }
            hudEnabled = Boolean.parseBoolean(p.getProperty("hud", "true"));
        } catch (IOException e) {
            System.err.println("[DimensityBoost] 配置读取失败：" + e.getMessage());
        }
    }

    private static void saveConfig() {
        try {
            Files.createDirectories(CONFIG.getParent());
            Properties p = new Properties();
            p.setProperty("mode", mode.name());
            p.setProperty("hud", Boolean.toString(hudEnabled));
            try (var out = Files.newOutputStream(CONFIG)) { p.store(out, "DimensityBoost client settings"); }
        } catch (IOException e) {
            System.err.println("[DimensityBoost] 配置保存失败：" + e.getMessage());
        }
    }
}
