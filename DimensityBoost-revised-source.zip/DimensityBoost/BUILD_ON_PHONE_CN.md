# 手机上编译 DimensityBoost（Termux）

> 说明：FCL 是启动器，不负责编译 Java 模组。这个项目需要 JDK 21、Gradle 和可访问 Maven 仓库的网络。此步骤会下载依赖，流量可能较大。

## 1. 安装 Termux
请从可信的 Termux 官方发布渠道安装 Termux，然后打开它。

## 2. 安装构建工具
在 Termux 中逐条执行：

```sh
pkg update
pkg upgrade
pkg install openjdk-21 gradle unzip
```

如果仓库提示找不到 `openjdk-21` 或 `gradle`，先更新 Termux 软件源；不要从不明网站下载 APK。

## 3. 解压源码
把 `DimensityBoost-source.zip` 放进手机的 Download 文件夹，然后在 Termux 中执行：

```sh
termux-setup-storage
cd ~/storage/downloads
unzip DimensityBoost-source.zip -d DimensityBoost
cd DimensityBoost
```

如果 ZIP 解压后多了一层目录，请 `cd` 到同时能看到 `build.gradle` 和 `settings.gradle` 的目录。

## 4. 编译
```sh
chmod +x build-termux.sh
./build-termux.sh
```

首次构建会联网下载 Minecraft、Fabric 和 Gradle 插件依赖。如果网络连接失败，编译就无法完成；这不是手机性能问题。

## 5. 安装到 FCL
成功后，找 `build/libs/` 里的 `dimensityboost-0.1.0.jar`，复制到 Minecraft Java 1.21.11 对应实例的 `mods` 文件夹。该实例需要 Fabric Loader、对应版本 Fabric API 和 Java 21。

## 6. 测试
进入世界后按 `O` 切换模式，按 `I` 显示/隐藏 HUD。若 FCL 使用的按键映射无法触发这些按键，可在游戏的“选项 → 控制 → 按键绑定”中检查按键设置。

## 如果失败
把 Termux 中从 `FAILURE: Build failed` 开始到最后的错误文字复制发给 ChatGPT。不要只发一张被截断的截图。构建前建议备份世界。
