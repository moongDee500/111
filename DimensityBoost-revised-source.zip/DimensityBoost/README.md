# DimensityBoost 0.1.0 — 源码原型

面向 Minecraft Java 1.21.11 / Fabric 的客户端模组，目标设备为天玑 9500 + Fold Craft Launcher。

## 当前实现
- 性能优先、均衡、低发热、自动调节四种模式。
- HUD 显示 FPS、客户端主循环耗时估算、JVM 内存、渲染距离。
- `O` 切换模式，`I` 开关 HUD。
- 配置保存到 `config/dimensityboost.properties`。
- 自动模式每 5 秒根据 FPS 保守地调整渲染距离。

## 构建要求
JDK 21、Gradle、Minecraft 1.21.11 Fabric 环境。使用 IntelliJ IDEA 打开本项目并同步 Gradle，或在项目目录运行 `gradle build`。生成的 JAR 位于 `build/libs/`。

## 在 FCL 安装
1. 使用 Minecraft Java 1.21.11 + Fabric Loader 的实例。
2. 确认该实例使用 Java 21。
3. 安装适用于 1.21.11 的 Fabric API。
4. 将构建出的 `dimensityboost-0.1.0.jar` 放进该实例的 `mods` 文件夹。
5. 进游戏按 O 切换模式、按 I 显示/隐藏 HUD。

## 重要说明
这是尚未在真实设备上测试的初版源码，不会超频，也不能直接控制 Android 温控策略。HUD 中的客户端循环耗时不是服务器 TPS。自动模式只调整渲染距离，实际表现仍取决于 FCL 渲染后端、驱动、游戏设置和其他模组。建议先备份存档再测试。
