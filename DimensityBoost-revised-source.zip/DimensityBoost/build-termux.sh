#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

echo "== DimensityBoost build helper for Termux =="
if ! command -v java >/dev/null 2>&1; then
  echo "未找到 Java。请先执行：pkg update && pkg install openjdk-21 gradle"
  exit 1
fi
java -version
if ! command -v gradle >/dev/null 2>&1; then
  echo "未找到 Gradle。请先执行：pkg install gradle"
  exit 1
fi

echo "开始下载 Fabric/Minecraft 构建依赖；需要可用网络。"
gradle --no-daemon build
echo
echo "如果成功，JAR 在 build/libs/ 目录："
find build/libs -maxdepth 1 -type f -name '*.jar' -print
